
#include <iostream>
#include <string>
#include <sstream>
#include <list>
#include <vector>
#include <math.h>
#include <stdlib.h>


using namespace std;

class noZeros {
  //declarations and prototypes.
  private:
    int index;
    double value;
  public:
  //default constructor
  noZeros() {
    index = 0;
    value = 0.0;
  }
  
  noZeros(int index, double value) {
    this->index = index;
    this->value = value;
  }
  int getIndex() const {
    return index;
  }

  double getValue() const {
    return value;
  }
  
  void setIndex(int index) {
    this->index= index;
  }

  void setValue(double value) {
    this->value = value;
  }
  //Overloading IO
  friend istringstream& operator>>(istringstream& input, noZeros& base) {
    string indexString,valueString;
    input >> indexString;
    input >> valueString;
    base.setIndex(atoi(indexString.c_str()));
    base.setValue(atof(valueString.c_str()));
    return input;
  };

  friend ostream& operator<<(ostream &output, const noZeros& base) {
    stringstream stream;
    stream << base.getIndex() <<" "<< base.getValue()<<" ";
    output << stream.str();
    return output;
  };
};

typedef list<noZeros> sparseRow;
typedef vector<sparseRow> sparseMatrix;

void readMat(sparseMatrix *rows, int *colCount);
void transPoseMatrix(const sparseMatrix rows, int colCount, sparseMatrix *transPosed );

int main(int argc, char *argv[]){
  //declarations
  int colCount;
  sparseMatrix rows;
  vector<sparseRow> transPosed;
  //read the compressed matrix from IO
  readMat(&rows, &colCount);
  //transpose matrix 
  transPoseMatrix(rows, colCount,&transPosed);
  //output value
  for (sparseRow row : transPosed) {
    for(noZeros value : row) {
        cout << value;
    }
    cout << endl;
  }
}

void readMat(sparseMatrix *rows, int *colCount){
  //initialisation and declarations
  *colCount = 0;
  string line;
  sparseRow row;
  noZeros val;
  //read every line
  while (getline(cin, line)){
    //call overloaded IO to take in matrix
    istringstream lstream(line) ;
    //take row and insert it into noZeros object
    while(lstream >> val) {
        row.push_back(val);
    }
    //add the row to the matrix
    rows->push_back(row);
    //reseting values and incrementing colCount
    row.clear();
    (*colCount)++;
 }
}
void transPoseMatrix(const sparseMatrix rows, int colCount, sparseMatrix *transPosed){
  /* Initialising the size of the transposed 
   * matrix with colCount which was set earlier.
   */
  for(int i =0; i < colCount; i++){
    sparseRow row;
    transPosed->push_back(row);
  }
  int count = 1;
  noZeros put;
  //populate transposed matrix
  for(sparseRow row : rows){
    for(noZeros val : row){
      noZeros put(count,val.getValue());
      (*transPosed)[val.getIndex() - 1].push_back(put);
    }
    count++;
  }
  
}


