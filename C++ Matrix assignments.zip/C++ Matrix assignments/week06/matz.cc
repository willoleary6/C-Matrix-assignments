#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <math.h>
#include <vector>

using namespace std;

int main(int argc, char *argv[]){
  //validating user input
  if(argc != 3){
    cout << "Error Invalid number of arguements. -- ./matz [row count] [column count]" << endl;
    exit(0);
  }
  int rowCount,colCount;
  rowCount = atoi(argv[1]);
  colCount = atoi(argv[2]);
  //create a vector to hold each row of the matrix
  vector<float> rows;
  rows.resize(colCount);

  int noZeroCount = 0;
  int noZerosInColumn;

  //matching paddys example executable
  cout << rowCount << endl;
  
  for(int i = 0; i < rowCount; i++){
    noZerosInColumn = 0;
    int j;
    for(j = 0; j < colCount; j++){
      //read in matrix
      cin >> rows[j];
      if(rows[j] != 0){
	noZerosInColumn++;
      }
    }
    //mathcing paddys output
    cout << noZerosInColumn << " ";
    //printing out column
    for(j = 0; j < colCount; j++){
      if(rows[j] != 0){
	cout << j+1 << " " << rows[j] << " ";
      }
    }
    cout << endl;
    //adding number of non-zero numbers in this row to the total count
    noZeroCount += noZerosInColumn; 
  }
  //printing final count
  cout << noZeroCount << endl;
  exit(0); 
}
