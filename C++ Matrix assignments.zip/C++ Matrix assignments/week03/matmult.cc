#include <fstream>

#include <iostream>

#include <math.h>

#include <stdlib.h>

using namespace std;




void readArr(int, int, double **);

void multArrs(int, double **, int, double **, int, double **);

void printResult(int ar, int bc ,double **C);


int main(int argc, char *argv[])

{
  if(argc == 5){

      int ar = atoi(argv[1]);

      int ac = atoi(argv[2]);

      int br = atoi(argv[3]);

      int bc = atoi(argv[4]);
      if (ac != br)

      {

        cerr<< "Matrix dimensions mismatch; exiting.\n";

        exit(-1);

      }


      // reserve space for the three arrays

      double **A = new double*[ar];	// each el. of this points to a row of A

      for (int i = 0; i < ar; i++)

        A[i] = new double[ac];	// a row of 'ac' floats


      double **B = new double*[br];

      for (int i = 0; i < br; i++)

        B[i] = new double[bc];	// a row of 'bc' floats


      double **C = new double*[ar];

      for(int i = 0; i < ar; i++){

          C[i] = new double[bc];

      }



      readArr(ar, ac, A);

      readArr(br, bc, B);


      multArrs(ar, A, bc, B, ac, C);

      printResult(ar,bc,C);

      // now print out answer, nice and plainly

    }else{

        cerr << "Not enough arguements" << endl;

        exit(-1);

    }

}


// read from kbd into this array, row by row

//  for a total of r x c entries;

//  WARNING: space for array must have been reserved beforehand

void readArr(int r, int c, double **arr)

{
 for(int i = 0; i < r; i++){
   for(int j = 0; j < c; j++){
	cin >> arr[i][j];
      }

  }

}


void multArrs(int ar, double **A, int bc, double **B, int ac, double **C)

{


    for(int i = 0; i < ar; ++i){

        for(int j = 0; j < bc; ++j){

          for(int k = 0; k < ac; ++k){

              C[i][j] += A[i][k] * B[k][j];

          }

      }

    }

}


void printResult(int ar, int bc ,double **C){

    for(int i = 0; i < ar; i++){

        for(int j = 0; j < bc; j++){

            cout << C[i][j] << " ";

        }

        cout << endl;

    }

}


