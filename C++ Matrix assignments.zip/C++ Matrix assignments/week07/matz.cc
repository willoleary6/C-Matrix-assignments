#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <math.h>
#include <stdlib.h>

using namespace std;

int main(int argc, char *argv[]){
  double epsilon = 0;
  //validiating input
  if(argc > 2 && string(argv[1])  == "-e")
    epsilon = fabs(strtod(argv[2],0));
    string input;
    double value;
    int location;
    //going through each line provided 
    while(getline(cin,input)){
      istringstream lstream(input);
      location = 0;
      //read in each value
      while(lstream >> value){
	location++;
	if(fabs(value) > epsilon){
	  cout << location << " " << value << " "; 
	}
      }
      cout << endl;
  }
}
